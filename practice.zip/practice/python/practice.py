##
##------------Python operatorss------------------------

##a="python\t"
##b="programming"
##print(a+b)
##para='''yfkuyckuyfuky
##                fydgfkyftydtkd
##                     gyfhkufgckytrfyughffiutfgfd
##                         hghgjgliugg'''
##print(para)
##
##
##name=str(input("enter the name: "))
##print(f"{name} is your name")
##
##
##
##a=int(input("enter the number 1: "))
##b=int(input("enter the number 2: "))
##total=(a+b)
##print(f" the total of {a} plus {b} is {total}")
##
##
##name=str(input("Enter Your Name: "))
##age=int(input("Enter Your Age: "))
##print(f"Your Name is {name} and you are {age} years old")
##
##
##a=int(input("Enter The Number 1: "))
##first=(a//10)
##second=(a%10)
##print(f"the first number is {first} and the second number is {second} ")
##sum=(first + second)
##print(sum)
##
##
##a=5
##b=4
##print(a>b)
##print(a<b)
##print(a>=b)
##print(a<=b)
##print(a==b)
##print(a!=b)
##
##
##a=4.5
##b=4
##print((a>b)and(a<b))
##print((a>b)or(a<b))
##print(not(a>b))
##print(not(a<b))
##print((a==b)and (a!=b))
##print((a==b)or(a!=b))
##print((a<=b) and (a>=b))
##print((a<=b) or (a>=b))
##print((a!=b)and (a!=b))
##print(not(a==b))
##print(not(a!=b))
##
##
##print('Boy' is' boy')
##print('Boy' is not 'boy')
##print('Boy' is 'Boy')
##print('Boy' is not 'Boy')
##
##
##a="she"
##b="She"
##print(a is b)
##print(a is not b)
##print(a and b)
##print(a or b)
##
##
##a=[1,2,3,4,5,6]
##print(5 in a)
##print(5 not in a

##------------find the negative or postive number------------------------

##num=int(input("Enter the number: "))
##if num>=0:
##    print("The Number Is Positive")
##else:
##    print("The Number Is Negative")

##------------find the even or odd number ------------------------

##num=int(input("enter the number: "))
##if num%2==0:
##     print("number is even")
##elif num%2!=0:
##     print("number is odd")
##else:
##    print("invalid number")
##
##
##num=int(input("enter the number: "))
##if num/2==float:
##     print("number is odd")
##else:
##    print("number is even")

##------------find the Gradee ------------------------

##mark=int(input("enter the mark: "))
##if mark<=100 and mark>=80:
##    print("Grade A")
##elif  mark<80 and mark>=60:
##    print("Grade B")
##elif  mark<60 and mark>=40:
##    print("Grade C")
##elif mark<40 and mark>=0:
##    print("Fail")
##else:
##    print("Invalid Mark")

##----------Important  Topic------------------------

##print(1000 is 1000)

##
##a=b=100;
##print(id(a), id(b))


##a=100
##b=int("100")
##print(a is b)


##a=257
##b=int("257")
##print(a is b)


##a=256
##b=str(a)
##print(type(b))

##------------Concadination------------------------

##x="1" + "1"
##print(x)

##------------find the vowel or consonant ------------------------


##letter=str(input("enter the letter: "))
##if letter =="a" or letter=="e" or letter=="i" or letter=="o" or letter=="u":
##    print("vowel")
##else:
##    print("consonant")

##------------Python Case ------------------------

##x="PYthon"
##print(x.upper())
##print(x.lower())
##print(x.swapcase())

##------------find the greastest among three------------------------

##letter=str(input("enter the letter:"))
##if letter==letter.upper() :
##    print("upper case")
##elif letter==letter.lower():
##    print("lower case")
##else:
##    print("invalid letter")

##------------find the greatest among three using string formattion------------------------

##x=15;
##y=34;
##z=212;
##if x>y and x>z:
##    print(f"{x} is greater")
##elif y>x and y>z:
##    print(f"{y} is greater")
##else:
##    print(f"{z} is greater")

##------------find the greatest num through input ------------------------

##x=int(input("enter number 1: "))
##y=int(input("enter number 2: "))
##z=int(input("enter number 3: "))
##if x>y and x>z:
##    print(f"{x} is greater")
##elif y>x and y>z:
##    print(f"{y} is greater")
##else:
##    print(f"{z} is greater")

##------------find the vowel even if it is in any case ------------------------


##l=input("enter the letter: ")
##letter=l.lower()
##if letter =="a" or letter=="e" or letter=="i" or letter=="o" or letter=="u":
##    print("vowel")
##else:
##    print("consonant")

##------------find the triangle type ------------------------

##a=int(input("enter number 1: "))
##b=int(input("enter number 2: "))
##c=int(input("enter number 3: "))
##if a==b==c:
##    print("Equilateral Triangle")
##elif a!=b!=c:
##    print("Scalene Triangle")
##else:
####    print("Isosceles Triangle")

##------------find the triangle type ------------------------

##a=int(input("enter number 1: "))
##b=int(input("enter number 2: "))
##c=int(input("enter number 3: "))
##if a==b==c:
##    print("Equilateral Triangle")
##elif a!=b==c or a==b!=c or a==c!=b:
##    print("Isosceles Triangle")
##else:
##    print("Scalene Triangle")

##------------find the triangle type ------------------------

##a=int(input("enter number 1: "))
##b=int(input("enter number 2: "))
##c=int(input("enter number 3: "))
##if a==b==c:
##    print("Equilateral Triangle")
##elif a==b or a==c or b==c:
##    print("Isosceles Triangle")
##else:
##    print("Scalene Triangle")


    



    



               
            
            


















    









