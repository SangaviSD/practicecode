##for i in range(1,11):
##    print("6*",i ,"=",i*6)
##
####list1=[10,20,30,40,50]
##sum1=0
##avg=1
##for i in list1:
##    sum1=sum1+i
##    avg=avg%i
##print(sum1)
##print(avg)

##list1=[]
##for i in range(100,401,2):
##    list1.append(i)
##print(list1)

##for i in range(1,51):
##    if (i%3==0) and (i%5==0):
##        print("fizzbuzz")
##    elif i%5==0:
##        print("buzz")
##    elif i%3==0:
##        print("fizz")
##    else:
####        print(i)
##
##list1=[1,2,3,4,5,6,7]
##even=0
##odd=0
##for i in list1:
##    if i%2==0:
##        even=even+1
##    else:
##        odd=odd+1
##print("odd=",odd)
##print("even=",even)
##
##for i in range(1500,2701):
##    if (i%7==0) and (i%5==0):
##        print(i)

##a="python"
##b=" "
##for i in a:
##    b=i+b
##print(b)

a="123"
for i in range(2,-1,1):
    
##
##a=12345
##b=0
##for i in a:
##    b=b+i
##print(b)

    

        

    
    
        



        
        


