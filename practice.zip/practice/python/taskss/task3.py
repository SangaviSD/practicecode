##n=1
##while n<=20:
##    if n%7==0:
##        print(n)
##        n+=1
##print(n)

##n=50
##sum=0
##i=1
##while i<=n:
##    if i%2!=0:
##        sum=sum+i
##        i=i+1
####print(sum)
##
##
##n=5
##sum=1
##i=1
##while i<=5:
##    sum=sum*i
##    i=i+1
##print(sum)
##
##
####n=1
##while n<=50:
##    if n%4==0:
##        n+=1
##        continue
##    print(n)
##    n+=1
        

##n=1
##while n<=50:
##    if (n%7==0) and (n%5!=0):
##        print(n)
##    n+=1



##list1=[]
##n=123
##count=0
##while n>=0:
##    list1.append(n)
##    count+=1
##print(count)
    

n=1
a,b=0,1
while n>=5:
    print(b)
    a,b=b,a+1
print(a)
    
    














